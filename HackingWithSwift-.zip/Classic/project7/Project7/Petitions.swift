//
//  Petitions.swift
//  Project7
//
//  Created by Paul Hudson on 23/10/2018.
//  Copyright © 2018 Paul Hudson. All rights reserved.
//

import Foundation

struct Petitions: Codable {
    var results: [Petition]
}
